from django.db import models


# Create your models here.
class Grocery(models.Model):
    proid = models.CharField(max_length=200)
    productName = models.CharField(max_length=200)
    unitPrice = models.CharField(max_length=50)
    quantity = models.CharField(max_length=50)
    totalPrice = models.CharField(max_length=50)


class Meta:
    db_table = "grocery"
