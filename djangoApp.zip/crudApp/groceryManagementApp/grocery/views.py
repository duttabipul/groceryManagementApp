from django.shortcuts import render, redirect
from grocery.forms import GroceryForm
from grocery.models import Grocery

# Create your views here.
def createGrocery(request):
    if request.method == "POST":
        form = GroceryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/show')
            pass
    else:
        form = GroceryForm()
    return render(request, "index.html", {'form':form})

def show(request):
    groceries = Grocery.objects.all()
    return render(request, "show.html", {"groceries": groceries})

def edit(request, id):
    grocery = Grocery.objects.get(id = id)
    #grocery.totalPrice = groceries.unitPrice*quantity
    return render(request, "edit.html", {"grocery": grocery})

def update(request, id):
    grocery = Grocery.objects.get(id = id)
    form = GroceryForm(request.POST, instance = grocery)
    if form.is_valid():
        form.save()
        return redirect('/show')
    return render(request, "edit.html", {"grocery": grocery})

def delete(request, id):
    grocery = Grocery.objects.get(id = id)
    grocery.delete()
    return redirect('/show')

